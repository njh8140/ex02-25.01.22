package kr.hkit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.hkit.domain.Criteria;
import kr.hkit.domain.ReplyVO;
import kr.hkit.mapper.ReplyMapper;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class ReplyServiceImplement implements ReplyService {
	
	@Setter(onMethod_ = @Autowired)
	//@Autowired
	private ReplyMapper mapper;
	
	
	@Override
	public int register(ReplyVO vo) {
		log.info("!!!! " + vo);
		return mapper.insert(vo);
	}

	@Override
	public ReplyVO get(long rno) {
		log.info("!!!! " + rno);
		return mapper.read(rno);
	}

	@Override
	public int modify(ReplyVO vo) {
		log.info("!!!! " + vo);
		return mapper.update(vo);
	}

	@Override
	public int remove(long rno) {
		log.info("!!!! " + rno);
		return mapper.delete(rno);
	}

	@Override
	public List<ReplyVO> getList(Criteria cri, long bno) {
		log.info("!!!!" + bno);
		return mapper.getListWithPaging(cri, bno);
	}

}
