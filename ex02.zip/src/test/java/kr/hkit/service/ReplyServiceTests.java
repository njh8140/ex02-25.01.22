package kr.hkit.service;

//import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import kr.hkit.domain.Criteria;
import kr.hkit.domain.ReplyVO;
import lombok.Setter;
import lombok.extern.log4j.Log4j;
//import oracle.net.ano.Service;


@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReplyServiceTests {

	@Setter(onMethod_ = @Autowired)
	private ReplyService service;
	
	//@Test
	public void testRegister() {
		
		ReplyVO vo = new ReplyVO();
		vo.setBno(467);
		vo.setReply("this is");
		vo.setReplyer("spa");
		
		log.info("!!!!"+vo);
		log.info(service.register(vo));
	}
	
	//@Test
	public void testGet() {
		
		log.info(service.get(5));
	}
	
	//@Test
	public void testModify() {
		
		ReplyVO vo = service.get(5);
		vo.setReply("댓글 수정");
		
		service.modify(vo);
	}
	
	//@Test
	public void testRemove() {
		
		service.remove(5);
	}
	
	@Test 
	public void testList() {
		
		service.getList(new Criteria(), 467).forEach(reply -> log.info(reply));
	}
	

}
