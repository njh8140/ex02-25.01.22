package kr.hkit.service;

import static org.junit.Assert.assertNotNull;

//import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import kr.hkit.domain.BoardVO;
import kr.hkit.domain.Criteria;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardServiceTests {
	@Setter(onMethod_ = @Autowired)
	private BoardService service;
	
	//@Test
	public void testExist() {
		assertNotNull(service);
		log.info(service);
	}
	
	//@Test
	public void testRegister() {
		BoardVO board = new BoardVO();
		board.setTitle("신규 글 등록");
		board.setContent("작성한 내용");
		board.setWriter("new00");
		
		service.register(board);
		log.info("신규 글 번호 : " + board.getBno());
	}
	
	//@Test
	public void testGet() {
		log.info("!!!!" + service.get(7L));
	}
	
	//@Test
	public void testModify() {
		BoardVO board = service.get(5);
		board.setTitle("수정한 글 등록");
		board.setContent("수정한 내용"); // 수정하고 싶은 부분만 수정 가능(주석처리해서)
		board.setWriter("modify00");
		
		log.info("!!!!수정결과 : " + service.modify(board));
	}
	
	//@Test
	public void testRemove() {
		log.info("!!!!삭제결과 : " + service.remove(8L));
	}
	
	@Test
	public void testGetList() {
		//service.getList().forEach(board->log.info("!!!! : " + board));
		
		service.getList(new Criteria(1, 5)).forEach(board->log.info("!!!! : " + board));
		
		/*
		 * List<BoardVO> boards = service.getList(); 
		 * for(BoardVO board : boards) {
		 * log.info("!!!! " + board); }
		 */
	}
}