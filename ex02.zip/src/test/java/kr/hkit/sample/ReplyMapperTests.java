package kr.hkit.sample;

import static org.junit.Assert.assertNotNull;

//import static org.junit.Assert.fail;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import kr.hkit.domain.Criteria;
import kr.hkit.domain.ReplyVO;
import kr.hkit.mapper.ReplyMapper;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class ReplyMapperTests {

	@Setter(onMethod_ = @Autowired)
	private ReplyMapper mapper;
	
	//@Test
	public void testMapper() {

		assertNotNull(mapper);
		log.info("!!!! " + mapper);
	}
	
	//@Test
	public void testInsert() {
		
		ReplyVO vo = new ReplyVO();
		vo.setBno(299);
		vo.setReply("하나 빼기");
		vo.setReplyer("일");
		
		mapper.insert(vo);
	}
	
	//@Test
	public void testRead() {
		
		ReplyVO vo = mapper.read(3L);
		log.info("!!!!" + vo);
	}
	
	//@Test
	public void testDelete() {
		
		mapper.delete(1L);
		log.info("!!!!" + mapper.delete(1L));
	}
	
	//@Test
	public void testUpdate() {
		
		//ReplyVO vo = new ReplyVO();
		//vo.setRno(3L);
		ReplyVO vo = mapper.read(3L);
		vo.setReply("that is");
		
		mapper.update(vo);
		log.info("!!!!" + mapper.update(vo));
	}
	
	@Test
	public void testList() {
		
		mapper.getListWithPaging(new Criteria(), 300).forEach(reply->log.info("!!!!"+reply));
	}
	
}